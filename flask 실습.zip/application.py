# html 파일들은 NOTION 이라는 사이트에서 만들었습니다.

from flask import Flask, render_template, request, redirect,url_for   # flask 모듈을 가져옮
import sys
application = Flask(__name__)   # Flask 객체를 application 변수에 할당
import database


@application.route("/")   # 인터넷 주소 부분을 의미
def house():
  return render_template("house.html")  # 연결된 파일

@application.route("/apply")
def apply():
  return render_template("apply.html")

@application.route("/applyphoto")
def photo_apply():
  location = request.args.get("location")   # 웹사이트에서 입력받은 값 가져오기
  cleaness = request.args.get("clean")
  built_in = request.args.get("built")

  if cleaness == None:
    cleaness = False
  else:
    cleaness = True

    database.save(location,cleaness,built_in)
  return render_template("apply_photo.html")

@application.route("/upload_done", methods=["POST"])  # POST: 주소창 뒤에 넘길 내용을 붙여서 넘길건지   GET: 안붙이고 넘어갈건지
def upload_done():
  upload_files = request.files["file"]    # 업로드한 파일명을 가져오기
  upload_files.save("static/img/{}.jpeg".format(database.now_index()))   # 사진을 파일에 저장해서 csv파일에 연결

  return redirect(url_for("house"))   # 메인화면으로 돌아가기


@application.route("/list")
def list():
  house_list = database.load_list()
  length = len(house_list)
  return render_template("list.html", house_list = house_list, length = length)

@application.route("/house_info/<int:index>/")    # 주소창에 값 가져오기
def house_info(index):
  house_info = database.load_house(index)
  location = house_info["location"]
  cleaness = house_info["cleaness"]
  built_in = house_info["built_in"]

  photo = f"img/{index}.jpeg"

  return render_template("house_info.html",location = location,cleaness = cleaness,built_in = built_in,photo = photo)   # house_info 의 location 변수에 현재 함수의 location 값 넣기


if __name__ == "__main__":    # 스크립트가 실행될 때
  application.run(port=5001)  